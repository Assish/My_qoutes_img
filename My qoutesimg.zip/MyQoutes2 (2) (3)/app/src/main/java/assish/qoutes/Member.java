package assish.qoutes;

public class Member {

    String image1;

    public Member(){}

    public String getImage() {
        return image1;
    }

    public void setImage(String image1) {
        this.image1 = image1;
    }

    public Member(String image1){
        this.image1=image1;
    }
}
